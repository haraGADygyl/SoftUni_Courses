create function timestamptz(date, time without time zone) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function timestamptz(date, time) is 'convert date and time to timestamp with time zone';

alter function timestamptz(date, time) owner to postgres;

